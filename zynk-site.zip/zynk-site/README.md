
# ZYNK — static site (ready for Vercel)

Ovo je jednostavna, statična one‑pager web stranica za ZYNK (Tailwind preko CDN‑a).

## Kako objaviti na Vercel (najlakše)

1) Napravi novi GitHub repo `zynk-site` i uploadaj ove datoteke (ili `Extract` pa `git push`).  
2) Na https://vercel.com → **New Project** → **Import Git Repository** → odaberi `zynk-site`.  
3) Build postavke nisu potrebne (static), Vercel će sam servirati `index.html`.  
4) Dobit ćeš URL tipa `https://zynk-site.vercel.app`.

## Kako zamijeniti slike
- `assets/logo.svg` → zamijeni svojim SVG/PNG logom.
- `assets/hero.png` → zamijeni mockupom hoodice/majice.

## Link na shop
U `index.html` promijeni `href="#"` na URL tvog Etsy/Redbubble/Shopify shopa.

Sretno! 💪
